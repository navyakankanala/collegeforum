<?php
$conn=new mysqli("sql112.infinityfreeapp.com","epiz_22360572","nknpvo1nT","epiz_22360572_minipro1");
if(!$conn) die("Database connection error".mysqli_error($conn));
session_start();

if(isset($_SESSION['user']))
{
	$user=$_SESSION['user'];

	$sql="select `uname` from `reg` where `email`='$user'";
	$query=mysqli_query($conn,$sql);
	$row=mysqli_fetch_array($query);
	$username=$row['uname'];
}
if(!isset($_SESSION['user']))
{
	header("Location:login1.php");
}


?>
